 /* start Functions w the name CB_FunctionName */

 $(document).ready(function(){
    // Activate Carousel
    $("#myCarousel").carousel({interval: 5000});
 });